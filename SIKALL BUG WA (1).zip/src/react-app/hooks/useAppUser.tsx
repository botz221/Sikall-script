import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface AppUser {
  id: number;
  username: string;
  role: string;
  duration: string;
  expires_at: string | null;
  is_active: boolean;
}

interface AppUserContextValue {
  user: AppUser | null;
  isPending: boolean;
  fetchUser: () => Promise<void>;
  logout: () => Promise<void>;
}

const AppUserContext = createContext<AppUserContextValue | undefined>(undefined);

export function AppUserProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AppUser | null>(null);
  const [isPending, setIsPending] = useState(true);

  const fetchUser = async () => {
    try {
      const response = await fetch('/api/app-users/me');
      if (response.ok) {
        const data = await response.json();
        setUser(data);
      } else {
        setUser(null);
      }
    } catch (error) {
      console.error('Failed to fetch user:', error);
      setUser(null);
    } finally {
      setIsPending(false);
    }
  };

  const logout = async () => {
    try {
      await fetch('/api/app-users/logout', { method: 'POST' });
      setUser(null);
    } catch (error) {
      console.error('Logout failed:', error);
    }
  };

  useEffect(() => {
    fetchUser();
  }, []);

  return (
    <AppUserContext.Provider value={{ user, isPending, fetchUser, logout }}>
      {children}
    </AppUserContext.Provider>
  );
}

export function useAppUser() {
  const context = useContext(AppUserContext);
  if (context === undefined) {
    throw new Error('useAppUser must be used within AppUserProvider');
  }
  return context;
}

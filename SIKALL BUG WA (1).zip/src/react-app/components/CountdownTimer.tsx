import { useState, useEffect } from 'react';
import { Clock } from 'lucide-react';

export default function CountdownTimer() {
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  });

  useEffect(() => {
    const calculateTimeLeft = () => {
      const targetDate = new Date('2026-01-01T00:00:00').getTime();
      const now = new Date().getTime();
      const difference = targetDate - now;

      if (difference > 0) {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
          minutes: Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60)),
          seconds: Math.floor((difference % (1000 * 60)) / 1000)
        });
      } else {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
      }
    };

    calculateTimeLeft();
    const timer = setInterval(calculateTimeLeft, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="bg-gradient-to-br from-purple-900/50 via-blue-900/50 to-purple-900/50 border border-purple-700/30 rounded-2xl p-6 backdrop-blur-sm">
      <div className="flex items-center justify-center gap-2 mb-4">
        <Clock className="w-5 h-5 text-purple-400" />
        <h3 className="text-lg font-semibold text-purple-300">Update Besar 2026</h3>
      </div>
      
      <p className="text-center text-gray-300 text-sm mb-6">
        Website akan diupdate dengan fitur yang lebih bagus
      </p>

      <div className="grid grid-cols-4 gap-3">
        <div className="bg-black/40 rounded-xl p-3 border border-purple-700/30">
          <div className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-blue-400 text-center">
            {timeLeft.days}
          </div>
          <div className="text-xs text-gray-400 text-center mt-1">Hari</div>
        </div>

        <div className="bg-black/40 rounded-xl p-3 border border-purple-700/30">
          <div className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-blue-400 text-center">
            {timeLeft.hours}
          </div>
          <div className="text-xs text-gray-400 text-center mt-1">Jam</div>
        </div>

        <div className="bg-black/40 rounded-xl p-3 border border-purple-700/30">
          <div className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-blue-400 text-center">
            {timeLeft.minutes}
          </div>
          <div className="text-xs text-gray-400 text-center mt-1">Menit</div>
        </div>

        <div className="bg-black/40 rounded-xl p-3 border border-purple-700/30">
          <div className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-blue-400 text-center">
            {timeLeft.seconds}
          </div>
          <div className="text-xs text-gray-400 text-center mt-1">Detik</div>
        </div>
      </div>

      <div className="mt-6 p-4 bg-purple-900/20 rounded-lg border border-purple-700/20">
        <p className="text-center text-sm text-purple-300">
          ✨ Fitur baru, tampilan lebih modern, dan pengalaman yang lebih baik
        </p>
      </div>
    </div>
  );
}

import { ReactNode, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { useAppUser } from '@/react-app/hooks/useAppUser';

export default function ProtectedRoute({ children }: { children: ReactNode }) {
  const { user, isPending } = useAppUser();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isPending && !user) {
      navigate('/login');
    }
  }, [user, isPending, navigate]);

  if (isPending) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-400">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return <>{children}</>;
}

import { useState, useEffect } from 'react';
import { User, Lock, LogIn } from 'lucide-react';
import { useNavigate } from 'react-router';
import { useAppUser } from '@/react-app/hooks/useAppUser';

export default function UserLogin() {
  const navigate = useNavigate();
  const { user, isPending, fetchUser } = useAppUser();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (!isPending && user) {
      navigate('/');
    }
  }, [user, isPending, navigate]);

  const playErrorSound = () => {
    const audio = new Audio('https://files.catbox.moe/xva72f.mp3');
    audio.play().catch(err => console.error('Failed to play error sound:', err));
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/app-users/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });

      if (response.ok) {
        await fetchUser();
        navigate('/');
      } else {
        const data = await response.json();
        // Translate error messages to Indonesian
        let errorMessage = data.error || 'Login failed';
        if (errorMessage === 'Invalid username or password') {
          errorMessage = 'Username atau password salah. Hubungi admin jika Anda belum terdaftar.';
        } else if (errorMessage === 'Account is inactive') {
          errorMessage = 'Akun tidak aktif. Hubungi admin.';
        } else if (errorMessage === 'Account has expired') {
          errorMessage = 'Akun telah kedaluwarsa. Hubungi admin.';
        } else if (errorMessage === 'Username and password required') {
          errorMessage = 'Username dan password harus diisi.';
        }
        setError(errorMessage);
        playErrorSound();
      }
    } catch (err) {
      setError('Terjadi kesalahan jaringan. Silakan coba lagi.');
      playErrorSound();
    } finally {
      setIsLoading(false);
    }
  };

  

  return (
    <div className="min-h-screen bg-black text-white flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo/Title */}
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <User className="w-10 h-10" />
          </div>
          <h1 className="text-2xl font-bold mb-2">SIKALL BUG WA</h1>
          <p className="text-gray-400">Sign in to continue</p>
        </div>

        {/* Login Form */}
        <div className="bg-gray-900 border border-gray-800 rounded-xl p-6">
          <form onSubmit={handleLogin} className="space-y-4">
            {error && (
              <div className="bg-red-900/30 border border-red-800/50 rounded-lg p-3">
                <p className="text-red-300 text-sm">{error}</p>
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Username
              </label>
              <div className="relative">
                <input
                  type="text"
                  placeholder="Enter your username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full bg-black border border-gray-800 rounded-lg px-4 py-3 pl-11 text-white placeholder-gray-500 focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600"
                  required
                />
                <div className="absolute left-3 top-1/2 -translate-y-1/2">
                  <User className="w-5 h-5 text-gray-500" />
                </div>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Password
              </label>
              <div className="relative">
                <input
                  type="password"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-black border border-gray-800 rounded-lg px-4 py-3 pl-11 text-white placeholder-gray-500 focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600"
                  required
                />
                <div className="absolute left-3 top-1/2 -translate-y-1/2">
                  <Lock className="w-5 h-5 text-gray-500" />
                </div>
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 disabled:from-gray-700 disabled:to-gray-700 rounded-lg px-4 py-3 text-white font-medium transition-colors flex items-center justify-center space-x-2"
            >
              {isLoading ? (
                <>
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span>Signing in...</span>
                </>
              ) : (
                <>
                  <LogIn className="w-5 h-5" />
                  <span>SIGN IN</span>
                </>
              )}
            </button>
          </form>

          <div className="mt-6 pt-6 border-t border-gray-800 text-center">
            <p className="text-sm text-gray-400">
              Hubungi admin untuk mendapatkan akses akun
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

import { useState, useEffect } from 'react';
import { ArrowLeft, Smartphone, Globe, Wifi, Battery, HardDrive, Cpu, Clock } from 'lucide-react';
import { useNavigate } from 'react-router';

export default function SenderInfo() {
  const navigate = useNavigate();
  const [deviceInfo, setDeviceInfo] = useState({
    userAgent: '',
    platform: '',
    language: '',
    screenResolution: '',
    timezone: '',
    cookiesEnabled: false,
    onlineStatus: false,
    connection: '',
  });

  useEffect(() => {
    const connection = (navigator as any).connection || (navigator as any).mozConnection || (navigator as any).webkitConnection;
    
    setDeviceInfo({
      userAgent: navigator.userAgent,
      platform: navigator.platform,
      language: navigator.language,
      screenResolution: `${window.screen.width}x${window.screen.height}`,
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      cookiesEnabled: navigator.cookieEnabled,
      onlineStatus: navigator.onLine,
      connection: connection?.effectiveType || 'Unknown',
    });
  }, []);

  const InfoCard = ({ icon: Icon, label, value }: { icon: any, label: string, value: string }) => (
    <div className="bg-gray-900 border border-gray-800 rounded-xl p-4">
      <div className="flex items-start space-x-3">
        <div className="w-10 h-10 rounded-lg bg-gray-800 flex items-center justify-center flex-shrink-0">
          <Icon className="w-5 h-5 text-blue-400" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="text-xs text-gray-500 mb-1">{label}</div>
          <div className="text-sm text-gray-300 break-all">{value}</div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <div className="bg-gray-900 px-4 py-4 flex items-center space-x-4 border-b border-gray-800">
        <button 
          onClick={() => navigate('/')}
          className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-gray-700 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-xl font-bold">Sender Info</h1>
      </div>

      {/* Main Content */}
      <div className="px-6 py-6 space-y-4">
        {/* Status Cards */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-gradient-to-br from-green-900/40 to-emerald-900/40 border border-green-800/50 rounded-xl p-4 text-center">
            <Wifi className="w-8 h-8 text-green-400 mx-auto mb-2" />
            <div className="text-sm text-gray-400">Connection</div>
            <div className="text-lg font-bold text-green-300">{deviceInfo.connection}</div>
          </div>
          <div className={`bg-gradient-to-br ${deviceInfo.onlineStatus ? 'from-blue-900/40 to-cyan-900/40 border-blue-800/50' : 'from-red-900/40 to-orange-900/40 border-red-800/50'} border rounded-xl p-4 text-center`}>
            <Globe className={`w-8 h-8 ${deviceInfo.onlineStatus ? 'text-blue-400' : 'text-red-400'} mx-auto mb-2`} />
            <div className="text-sm text-gray-400">Status</div>
            <div className={`text-lg font-bold ${deviceInfo.onlineStatus ? 'text-blue-300' : 'text-red-300'}`}>
              {deviceInfo.onlineStatus ? 'Online' : 'Offline'}
            </div>
          </div>
        </div>

        {/* Device Information */}
        <div className="space-y-3 pt-2">
          <h2 className="text-lg font-semibold text-gray-300 px-2">Device Information</h2>
          
          <InfoCard 
            icon={Smartphone}
            label="Platform"
            value={deviceInfo.platform}
          />

          <InfoCard 
            icon={HardDrive}
            label="Screen Resolution"
            value={deviceInfo.screenResolution}
          />

          <InfoCard 
            icon={Globe}
            label="Language"
            value={deviceInfo.language}
          />

          <InfoCard 
            icon={Clock}
            label="Timezone"
            value={deviceInfo.timezone}
          />

          <InfoCard 
            icon={Cpu}
            label="User Agent"
            value={deviceInfo.userAgent}
          />

          <div className="bg-gray-900 border border-gray-800 rounded-xl p-4">
            <div className="flex items-start space-x-3">
              <div className="w-10 h-10 rounded-lg bg-gray-800 flex items-center justify-center flex-shrink-0">
                <Battery className="w-5 h-5 text-yellow-400" />
              </div>
              <div className="flex-1">
                <div className="text-xs text-gray-500 mb-1">Cookies</div>
                <div className={`text-sm font-medium ${deviceInfo.cookiesEnabled ? 'text-green-400' : 'text-red-400'}`}>
                  {deviceInfo.cookiesEnabled ? 'Enabled' : 'Disabled'}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* IP Information Section */}
        <div className="space-y-3 pt-4">
          <h2 className="text-lg font-semibold text-gray-300 px-2">Network Information</h2>
          
          <div className="bg-gradient-to-br from-purple-900/40 to-pink-900/40 border border-purple-800/50 rounded-xl p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="text-sm text-gray-400">IP Address</div>
              <Globe className="w-5 h-5 text-purple-400" />
            </div>
            <div className="text-xl font-bold text-purple-200">Loading...</div>
            <div className="text-xs text-gray-500 mt-1">Fetching external IP...</div>
          </div>
        </div>
      </div>
    </div>
  );
}

import { useState } from 'react';
import { ArrowLeft, Send, AlertTriangle } from 'lucide-react';
import { useNavigate } from 'react-router';

export default function WhatsAppAttack() {
  const navigate = useNavigate();
  const [phoneNumber, setPhoneNumber] = useState('');
  const [command, setCommand] = useState('.ezo-delay');
  const [count, setCount] = useState('10');
  const [isAttacking, setIsAttacking] = useState(false);
  const [progress, setProgress] = useState(0);

  const commands = [
    { value: '.ezo-delay', label: '.ezo-delay' },
    { value: '.ezo-blank', label: '.ezo-blank' },
    { value: '.ezo-freeze', label: '.ezo-freeze' },
    { value: '.ezo-cyber', label: '.ezo-cyber' },
    { value: '.ezo-forclose', label: '.ezo-forclose' },
  ];

  const handleAttack = () => {
    if (!phoneNumber || !command) return;
    
    setIsAttacking(true);
    setProgress(0);
    
    const total = parseInt(count);
    let current = 0;
    
    const interval = setInterval(() => {
      current++;
      setProgress((current / total) * 100);
      
      if (current >= total) {
        clearInterval(interval);
        setTimeout(() => {
          setIsAttacking(false);
          setProgress(0);
        }, 1000);
      }
    }, 100);
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <div className="bg-gray-900 px-4 py-4 flex items-center space-x-4 border-b border-gray-800">
        <button 
          onClick={() => navigate('/')}
          className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-gray-700 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="text-xl font-bold">WhatsApp Attack</h1>
      </div>

      {/* Warning Banner */}
      <div className="mx-6 mt-6 bg-gradient-to-r from-red-900/40 to-orange-900/40 border border-red-800/50 rounded-xl p-4 flex items-start space-x-3">
        <AlertTriangle className="w-6 h-6 text-red-400 flex-shrink-0 mt-0.5" />
        <div>
          <h3 className="font-semibold text-red-300 mb-1">Educational Purpose Only</h3>
          <p className="text-sm text-gray-400">This tool is for educational and testing purposes only. Misuse may violate terms of service.</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="px-6 py-6 space-y-6">
        {/* Phone Number Input */}
        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">
            Target Phone Number
          </label>
          <input
            type="tel"
            value={phoneNumber}
            onChange={(e) => setPhoneNumber(e.target.value)}
            placeholder="+62 812 3456 7890"
            className="w-full bg-gray-900 border border-gray-800 rounded-xl px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            disabled={isAttacking}
          />
        </div>

        {/* Command Selection */}
        <div>
          <label className="block text-sm font-medium text-gray-400 mb-3">
            Attack Command
          </label>
          <div className="space-y-2">
            {commands.map((cmd) => (
              <label
                key={cmd.value}
                className={`flex items-center space-x-3 p-4 rounded-xl border-2 cursor-pointer transition-all ${
                  command === cmd.value
                    ? 'bg-blue-900/20 border-blue-600'
                    : 'bg-gray-900 border-gray-800 hover:border-gray-700'
                } ${isAttacking ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                <input
                  type="radio"
                  name="command"
                  value={cmd.value}
                  checked={command === cmd.value}
                  onChange={(e) => setCommand(e.target.value)}
                  disabled={isAttacking}
                  className="w-5 h-5 text-blue-600 bg-gray-800 border-gray-700 focus:ring-blue-500 focus:ring-2"
                />
                <span className="font-mono text-white font-medium">{cmd.label}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Count Input */}
        <div>
          <label className="block text-sm font-medium text-gray-400 mb-2">
            Number of Messages
          </label>
          <input
            type="number"
            value={count}
            onChange={(e) => setCount(e.target.value)}
            min="1"
            max="100"
            className="w-full bg-gray-900 border border-gray-800 rounded-xl px-4 py-3 text-white placeholder-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            disabled={isAttacking}
          />
        </div>

        {/* Progress Bar */}
        {isAttacking && (
          <div className="space-y-2">
            <div className="flex justify-between text-sm text-gray-400">
              <span>Sending messages...</span>
              <span>{Math.round(progress)}%</span>
            </div>
            <div className="w-full h-2 bg-gray-900 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-green-500 to-emerald-500 transition-all duration-300"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        )}

        {/* Send Button */}
        <button
          onClick={handleAttack}
          disabled={isAttacking || !phoneNumber || !command}
          className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-500 hover:to-emerald-500 disabled:from-gray-800 disabled:to-gray-800 disabled:cursor-not-allowed rounded-xl py-4 flex items-center justify-center space-x-3 font-semibold transition-all"
        >
          <Send className="w-5 h-5" />
          <span>{isAttacking ? 'Sending...' : 'Start Attack'}</span>
        </button>

        {/* Stats Cards */}
        <div className="grid grid-cols-3 gap-4 pt-4">
          <div className="bg-gray-900 border border-gray-800 rounded-xl p-4 text-center">
            <div className="text-2xl font-bold text-green-400">{count}</div>
            <div className="text-xs text-gray-500 mt-1">Messages</div>
          </div>
          <div className="bg-gray-900 border border-gray-800 rounded-xl p-4 text-center">
            <div className="text-2xl font-bold text-blue-400">~{Math.round(parseInt(count) * 0.5)}s</div>
            <div className="text-xs text-gray-500 mt-1">Est. Time</div>
          </div>
          <div className="bg-gray-900 border border-gray-800 rounded-xl p-4 text-center">
            <div className="text-2xl font-bold text-purple-400">1</div>
            <div className="text-xs text-gray-500 mt-1">Target</div>
          </div>
        </div>
      </div>
    </div>
  );
}

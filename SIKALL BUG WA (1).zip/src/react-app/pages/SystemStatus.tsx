import { useState, useEffect } from 'react';
import { ArrowLeft, Activity, Cpu, HardDrive, Wifi, Server, Clock, CheckCircle } from 'lucide-react';
import { useNavigate } from 'react-router';

export default function SystemStatus() {
  const navigate = useNavigate();
  const [uptime, setUptime] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setUptime(prev => prev + 1);
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const formatUptime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <div className="bg-gray-900 px-4 py-4 flex items-center justify-between border-b border-gray-800">
        <div className="flex items-center space-x-4">
          <button 
            onClick={() => navigate('/')}
            className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-gray-700 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex items-center space-x-2">
            <Activity className="w-6 h-6 text-green-400" />
            <h1 className="text-xl font-bold">System Status</h1>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
          <span className="text-sm text-green-400">Online</span>
        </div>
      </div>

      <div className="px-6 py-6">
        {/* System Overview */}
        <div className="bg-gradient-to-br from-green-900/40 to-blue-900/40 border border-green-800/50 rounded-xl p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 rounded-full bg-green-500/20 flex items-center justify-center">
                <CheckCircle className="w-6 h-6 text-green-400" />
              </div>
              <div>
                <div className="text-lg font-semibold text-white">All Systems Operational</div>
                <div className="text-sm text-gray-400">No issues detected</div>
              </div>
            </div>
          </div>
        </div>

        {/* Uptime */}
        <div className="bg-gray-900 border border-gray-800 rounded-xl p-4 mb-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Clock className="w-5 h-5 text-blue-400" />
              <div>
                <div className="text-sm text-gray-400">System Uptime</div>
                <div className="text-xl font-bold text-white font-mono">{formatUptime(uptime)}</div>
              </div>
            </div>
          </div>
        </div>

        {/* System Metrics */}
        <div className="space-y-4 mb-6">
          <h2 className="text-lg font-semibold text-gray-300">System Metrics</h2>

          {/* CPU Usage */}
          <div className="bg-gray-900 border border-gray-800 rounded-xl p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-3">
                <Cpu className="w-5 h-5 text-purple-400" />
                <span className="text-sm font-medium text-white">CPU Usage</span>
              </div>
              <span className="text-sm text-gray-400">23%</span>
            </div>
            <div className="w-full bg-gray-800 rounded-full h-2 overflow-hidden">
              <div className="bg-gradient-to-r from-purple-500 to-blue-500 h-full rounded-full" style={{ width: '23%' }}></div>
            </div>
          </div>

          {/* Memory Usage */}
          <div className="bg-gray-900 border border-gray-800 rounded-xl p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-3">
                <HardDrive className="w-5 h-5 text-blue-400" />
                <span className="text-sm font-medium text-white">Memory Usage</span>
              </div>
              <span className="text-sm text-gray-400">45%</span>
            </div>
            <div className="w-full bg-gray-800 rounded-full h-2 overflow-hidden">
              <div className="bg-gradient-to-r from-blue-500 to-cyan-500 h-full rounded-full" style={{ width: '45%' }}></div>
            </div>
          </div>

          {/* Disk Usage */}
          <div className="bg-gray-900 border border-gray-800 rounded-xl p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-3">
                <Server className="w-5 h-5 text-green-400" />
                <span className="text-sm font-medium text-white">Disk Usage</span>
              </div>
              <span className="text-sm text-gray-400">67%</span>
            </div>
            <div className="w-full bg-gray-800 rounded-full h-2 overflow-hidden">
              <div className="bg-gradient-to-r from-green-500 to-emerald-500 h-full rounded-full" style={{ width: '67%' }}></div>
            </div>
          </div>

          {/* Network Status */}
          <div className="bg-gray-900 border border-gray-800 rounded-xl p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-3">
                <Wifi className="w-5 h-5 text-cyan-400" />
                <span className="text-sm font-medium text-white">Network Status</span>
              </div>
              <span className="text-sm text-green-400">● Connected</span>
            </div>
            <div className="grid grid-cols-2 gap-4 mt-4">
              <div>
                <div className="text-xs text-gray-500 mb-1">Upload</div>
                <div className="text-sm font-semibold text-white">2.3 MB/s</div>
              </div>
              <div>
                <div className="text-xs text-gray-500 mb-1">Download</div>
                <div className="text-sm font-semibold text-white">5.8 MB/s</div>
              </div>
            </div>
          </div>
        </div>

        {/* Service Status */}
        <div className="space-y-4">
          <h2 className="text-lg font-semibold text-gray-300">Services</h2>

          <div className="bg-gray-900 border border-gray-800 rounded-xl p-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-white">Web Server</span>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-400" />
                  <span className="text-xs text-green-400">Running</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-white">Database</span>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-400" />
                  <span className="text-xs text-green-400">Running</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-white">API Gateway</span>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-400" />
                  <span className="text-xs text-green-400">Running</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-white">Cache Server</span>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-400" />
                  <span className="text-xs text-green-400">Running</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* System Info */}
        <div className="mt-6 bg-gray-900 border border-gray-800 rounded-xl p-4">
          <div className="text-sm font-medium text-gray-300 mb-3">System Information</div>
          <div className="space-y-2 text-xs">
            <div className="flex justify-between">
              <span className="text-gray-500">OS</span>
              <span className="text-gray-300">Linux 5.15.0</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">Platform</span>
              <span className="text-gray-300">Cloudflare Workers</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">Version</span>
              <span className="text-gray-300">1.0.0</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">Last Updated</span>
              <span className="text-gray-300">2 minutes ago</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

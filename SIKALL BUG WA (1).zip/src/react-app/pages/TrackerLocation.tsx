import { useState } from 'react';
import { ArrowLeft, MapPin, Search, Navigation } from 'lucide-react';
import { useNavigate } from 'react-router';

export default function TrackerLocation() {
  const navigate = useNavigate();
  const [phoneNumber, setPhoneNumber] = useState('');
  const [isTracking, setIsTracking] = useState(false);

  const handleTrack = (e: React.FormEvent) => {
    e.preventDefault();
    setIsTracking(true);
    // Simulate tracking
    setTimeout(() => {
      setIsTracking(false);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <div className="bg-gray-900 px-4 py-4 flex items-center justify-between border-b border-gray-800">
        <div className="flex items-center space-x-4">
          <button 
            onClick={() => navigate('/')}
            className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-gray-700 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex items-center space-x-2">
            <MapPin className="w-6 h-6 text-blue-400" />
            <h1 className="text-xl font-bold">Tracker Location</h1>
          </div>
        </div>
      </div>

      <div className="px-6 py-6">
        {/* Hero Image */}
        <div className="mb-6 rounded-xl overflow-hidden">
          <img 
            src="https://images.unsplash.com/photo-1569163139394-de4798aa62b6?w=800&h=400&fit=crop" 
            alt="Location Tracker"
            className="w-full h-48 object-cover"
          />
        </div>

        {/* Info Card */}
        <div className="bg-gradient-to-br from-blue-900/40 to-purple-900/40 border border-blue-800/50 rounded-xl p-6 mb-6">
          <div className="flex items-center space-x-3 mb-3">
            <Navigation className="w-6 h-6 text-blue-400" />
            <h2 className="text-lg font-semibold text-white">Track Phone Location</h2>
          </div>
          <p className="text-sm text-gray-300">
            Enter a phone number to track its real-time location on the map.
          </p>
        </div>

        {/* Track Form */}
        <form onSubmit={handleTrack} className="space-y-4 mb-6">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Phone Number
            </label>
            <div className="relative">
              <input
                type="tel"
                placeholder="+62 812 3456 7890"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                className="w-full bg-gray-900 border border-gray-800 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600"
              />
              <div className="absolute right-3 top-1/2 -translate-y-1/2">
                <MapPin className="w-5 h-5 text-gray-500" />
              </div>
            </div>
          </div>

          <button
            type="submit"
            disabled={isTracking}
            className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 disabled:from-gray-700 disabled:to-gray-700 rounded-lg px-4 py-3 text-white font-medium transition-colors flex items-center justify-center space-x-2"
          >
            {isTracking ? (
              <>
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                <span>Tracking...</span>
              </>
            ) : (
              <>
                <Search className="w-5 h-5" />
                <span>TRACK LOCATION</span>
              </>
            )}
          </button>
        </form>

        {/* Map Placeholder */}
        <div className="bg-gray-900 border border-gray-800 rounded-xl p-4 mb-6">
          <div className="aspect-video bg-gray-800 rounded-lg flex items-center justify-center">
            <div className="text-center">
              <MapPin className="w-12 h-12 text-gray-600 mx-auto mb-2" />
              <p className="text-gray-500 text-sm">Map will appear here</p>
            </div>
          </div>
        </div>

        {/* Location Details */}
        <div className="bg-gray-900 border border-gray-800 rounded-xl p-4">
          <h3 className="text-sm font-semibold text-gray-300 mb-3">Location Details</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-500">Latitude</span>
              <span className="text-gray-300">-</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">Longitude</span>
              <span className="text-gray-300">-</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">Address</span>
              <span className="text-gray-300">-</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">Last Updated</span>
              <span className="text-gray-300">-</span>
            </div>
          </div>
        </div>

        {/* Warning */}
        <div className="mt-6 bg-red-900/20 border border-red-800/50 rounded-lg p-4">
          <p className="text-xs text-red-300">
            ⚠️ This feature is for educational purposes only. Unauthorized tracking is illegal.
          </p>
        </div>
      </div>
    </div>
  );
}

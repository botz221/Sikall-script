import { useEffect, useState } from 'react';
import { Users, Menu, LogOut } from 'lucide-react';
import { useNavigate } from 'react-router';
import { useAuth } from '@getmocha/users-service/react';

export default function AdminPanel() {
  const navigate = useNavigate();
  const { user, isPending, logout } = useAuth();
  const [isAdmin, setIsAdmin] = useState(false);
  const [isChecking, setIsChecking] = useState(true);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('');
  const [duration, setDuration] = useState('');
  const [users, setUsers] = useState<any[]>([]);
  const [isCreating, setIsCreating] = useState(false);
  const [createError, setCreateError] = useState('');

  useEffect(() => {
    const checkAdmin = async () => {
      if (isPending) return;
      
      if (!user) {
        navigate('/admin/login');
        return;
      }

      try {
        const response = await fetch('/api/admin/check');
        if (response.ok) {
          setIsAdmin(true);
          loadUsers();
        } else {
          navigate('/');
        }
      } catch (error) {
        console.error('Admin check failed:', error);
        navigate('/');
      } finally {
        setIsChecking(false);
      }
    };

    checkAdmin();
  }, [user, isPending, navigate]);

  const loadUsers = async () => {
    try {
      const response = await fetch('/api/admin/users');
      if (response.ok) {
        const data = await response.json();
        setUsers(data);
      }
    } catch (error) {
      console.error('Failed to load users:', error);
    }
  };

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreateError('');
    setIsCreating(true);

    try {
      const response = await fetch('/api/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password, role, duration }),
      });

      if (response.ok) {
        setUsername('');
        setPassword('');
        setRole('');
        setDuration('');
        loadUsers();
      } else {
        const data = await response.json();
        setCreateError(data.error || 'Failed to create user');
      }
    } catch (error) {
      setCreateError('Network error. Please try again.');
    } finally {
      setIsCreating(false);
    }
  };

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  if (isPending || isChecking) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-400">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAdmin) {
    return null;
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <div className="bg-black px-4 py-3 flex items-center justify-between border-b border-gray-900">
        <button className="text-white">
          <Menu className="w-6 h-6" />
        </button>
        <button 
          onClick={handleLogout}
          className="flex items-center space-x-2 text-red-400 hover:text-red-300 transition-colors"
        >
          <LogOut className="w-5 h-5" />
          <span className="text-sm font-medium">Logout</span>
        </button>
      </div>

      <div className="px-6 py-6">
        {/* User Management Title */}
        <div className="flex items-center space-x-3 mb-4">
          <Users className="w-6 h-6 text-white" />
          <h1 className="text-xl font-bold text-white">User Management</h1>
        </div>

        {/* Hero Image */}
        <div className="mb-6 rounded-xl overflow-hidden">
          <img 
            src="https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=800&h=400&fit=crop" 
            alt="Admin Panel Hero"
            className="w-full h-48 object-cover"
          />
        </div>

        {/* Create New User Form */}
        <div className="mb-8">
          <div className="flex items-center space-x-2 mb-4">
            <Users className="w-5 h-5 text-white" />
            <h2 className="text-base font-semibold text-white">Create New User</h2>
          </div>

          <form onSubmit={handleCreateUser} className="space-y-3">
            {createError && (
              <div className="bg-red-900/30 border border-red-800/50 rounded-lg p-3">
                <p className="text-red-300 text-sm">{createError}</p>
              </div>
            )}

            <input
              type="text"
              placeholder="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full bg-gray-900 border border-gray-800 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-gray-700"
            />

            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-gray-900 border border-gray-800 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-gray-700"
            />

            <select
              value={role}
              onChange={(e) => setRole(e.target.value)}
              className="w-full bg-gray-900 border border-gray-800 rounded-lg px-4 py-3 text-gray-400 focus:outline-none focus:border-gray-700"
            >
              <option value="">Select Role</option>
              <option value="owner">Owner</option>
              <option value="admin">Admin</option>
              <option value="user">User</option>
            </select>

            <select
              value={duration}
              onChange={(e) => setDuration(e.target.value)}
              className="w-full bg-gray-900 border border-gray-800 rounded-lg px-4 py-3 text-gray-400 focus:outline-none focus:border-gray-700"
            >
              <option value="">Select Duration</option>
              <option value="1day">1 Day</option>
              <option value="7days">7 Days</option>
              <option value="30days">30 Days</option>
              <option value="lifetime">Lifetime</option>
            </select>

            <button
              type="submit"
              disabled={isCreating}
              className="w-full bg-gray-900 hover:bg-gray-800 disabled:bg-gray-800 border border-gray-800 rounded-lg px-4 py-3 text-white font-medium transition-colors flex items-center justify-center space-x-2"
            >
              {isCreating ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  <span>CREATING...</span>
                </>
              ) : (
                <>
                  <Users className="w-4 h-4" />
                  <span>CREATE USER</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* User List */}
        <div>
          <div className="flex items-center space-x-2 mb-4">
            <Users className="w-5 h-5 text-white" />
            <h2 className="text-base font-semibold text-white">User List</h2>
          </div>

          <div className="space-y-3">
            {users.length === 0 ? (
              <div className="bg-gray-900 border border-gray-800 rounded-lg px-4 py-3 text-center">
                <p className="text-gray-500 text-sm">No users yet</p>
              </div>
            ) : (
              users.map((appUser) => (
                <div key={appUser.id} className="bg-gray-900 border border-gray-800 rounded-lg px-4 py-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-white font-medium block">{appUser.username}</span>
                      <span className="text-gray-500 text-xs">
                        Created: {new Date(appUser.created_at).toLocaleDateString()}
                      </span>
                    </div>
                    <div className="text-right">
                      <span className="bg-gray-800 text-gray-300 text-xs px-2 py-1 rounded block mb-1">
                        {appUser.role}
                      </span>
                      <span className="text-gray-500 text-xs">{appUser.duration}</span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

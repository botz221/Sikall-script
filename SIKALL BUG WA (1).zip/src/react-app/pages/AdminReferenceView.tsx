export default function AdminReferenceView() {
  return (
    <div className="min-h-screen bg-white flex items-center justify-center p-4">
      <img 
        src="/admin_reference.jpg" 
        alt="Admin Reference" 
        className="max-w-full max-h-screen object-contain"
      />
    </div>
  );
}

export default function ReferenceView() {
  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-lg p-4">
        <h1 className="text-2xl font-bold mb-4">Reference Image</h1>
        <img src="/reference.jpg" alt="Reference" className="w-full" />
      </div>
    </div>
  );
}

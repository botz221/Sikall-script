import { useState } from 'react';
import { ArrowLeft, MapPin, Search, Phone, Globe, Building2, AlertCircle } from 'lucide-react';
import { useNavigate } from 'react-router';

interface TrackingResult {
  number: string;
  country: string;
  countryCode: string;
  carrier: string;
  location: string;
  type: string;
  valid: boolean;
  coordinates?: {
    lat: number;
    lng: number;
  };
}

export default function PhoneTracker() {
  const navigate = useNavigate();
  const [phoneNumber, setPhoneNumber] = useState('');
  const [isTracking, setIsTracking] = useState(false);
  const [result, setResult] = useState<TrackingResult | null>(null);
  const [error, setError] = useState('');

  const handleTrack = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setResult(null);
    
    if (!phoneNumber.trim()) {
      setError('Masukkan nomor telepon');
      return;
    }

    setIsTracking(true);

    try {
      const response = await fetch('/api/track-phone', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phoneNumber }),
      });

      if (response.ok) {
        const data = await response.json();
        setResult(data);
      } else {
        const data = await response.json();
        setError(data.error || 'Gagal melacak nomor');
      }
    } catch (err) {
      setError('Terjadi kesalahan jaringan');
    } finally {
      setIsTracking(false);
    }
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <div className="bg-gray-900 px-4 py-4 flex items-center justify-between border-b border-gray-800">
        <div className="flex items-center space-x-4">
          <button 
            onClick={() => navigate('/')}
            className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-gray-700 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex items-center space-x-2">
            <Phone className="w-6 h-6 text-blue-400" />
            <h1 className="text-xl font-bold">Lacak Nomor</h1>
          </div>
        </div>
      </div>

      <div className="px-6 py-6">
        {/* Hero Image */}
        <div className="mb-6 rounded-xl overflow-hidden">
          <img 
            src="https://images.unsplash.com/photo-1526628953301-3e589a6a8b74?w=800&h=400&fit=crop" 
            alt="Phone Tracker"
            className="w-full h-48 object-cover"
          />
        </div>

        {/* Info Card */}
        <div className="bg-gradient-to-br from-blue-900/40 to-purple-900/40 border border-blue-800/50 rounded-xl p-6 mb-6">
          <div className="flex items-center space-x-3 mb-3">
            <MapPin className="w-6 h-6 text-blue-400" />
            <h2 className="text-lg font-semibold text-white">Lacak Informasi Nomor</h2>
          </div>
          <p className="text-sm text-gray-300">
            Masukkan nomor telepon untuk melacak informasi negara, operator, dan lokasi umum.
          </p>
        </div>

        {/* Track Form */}
        <form onSubmit={handleTrack} className="space-y-4 mb-6">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Nomor Telepon
            </label>
            <div className="relative">
              <input
                type="tel"
                placeholder="+62 812 3456 7890"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                className="w-full bg-gray-900 border border-gray-800 rounded-lg px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600"
              />
              <div className="absolute right-3 top-1/2 -translate-y-1/2">
                <Phone className="w-5 h-5 text-gray-500" />
              </div>
            </div>
            <p className="mt-2 text-xs text-gray-500">
              Format: +62 untuk Indonesia, +1 untuk US, dll.
            </p>
          </div>

          {error && (
            <div className="bg-red-900/30 border border-red-800/50 rounded-lg p-3 flex items-start space-x-2">
              <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
              <p className="text-red-300 text-sm">{error}</p>
            </div>
          )}

          <button
            type="submit"
            disabled={isTracking}
            className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 disabled:from-gray-700 disabled:to-gray-700 rounded-lg px-4 py-3 text-white font-medium transition-colors flex items-center justify-center space-x-2"
          >
            {isTracking ? (
              <>
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                <span>Melacak...</span>
              </>
            ) : (
              <>
                <Search className="w-5 h-5" />
                <span>LACAK NOMOR</span>
              </>
            )}
          </button>
        </form>

        {/* Results */}
        {result && (
          <div className="space-y-4">
            {/* Status Badge */}
            <div className={`inline-flex items-center space-x-2 px-4 py-2 rounded-lg ${
              result.valid 
                ? 'bg-green-900/40 border border-green-800/50' 
                : 'bg-red-900/40 border border-red-800/50'
            }`}>
              <div className={`w-2 h-2 rounded-full ${result.valid ? 'bg-green-400' : 'bg-red-400'}`} />
              <span className={`text-sm font-medium ${result.valid ? 'text-green-300' : 'text-red-300'}`}>
                {result.valid ? 'Nomor Valid' : 'Nomor Tidak Valid'}
              </span>
            </div>

            {/* Phone Details */}
            <div className="bg-gray-900 border border-gray-800 rounded-xl p-5">
              <h3 className="text-sm font-semibold text-gray-300 mb-4 flex items-center space-x-2">
                <Phone className="w-4 h-4" />
                <span>Detail Nomor</span>
              </h3>
              <div className="space-y-3">
                <div className="flex items-start justify-between">
                  <span className="text-gray-500 text-sm">Nomor</span>
                  <span className="text-white text-sm font-mono">{result.number}</span>
                </div>
                <div className="flex items-start justify-between">
                  <span className="text-gray-500 text-sm flex items-center space-x-1">
                    <Globe className="w-3.5 h-3.5" />
                    <span>Negara</span>
                  </span>
                  <span className="text-white text-sm">{result.country} ({result.countryCode})</span>
                </div>
                <div className="flex items-start justify-between">
                  <span className="text-gray-500 text-sm flex items-center space-x-1">
                    <Building2 className="w-3.5 h-3.5" />
                    <span>Operator</span>
                  </span>
                  <span className="text-white text-sm">{result.carrier}</span>
                </div>
                <div className="flex items-start justify-between">
                  <span className="text-gray-500 text-sm flex items-center space-x-1">
                    <MapPin className="w-3.5 h-3.5" />
                    <span>Lokasi</span>
                  </span>
                  <span className="text-white text-sm">{result.location}</span>
                </div>
                <div className="flex items-start justify-between">
                  <span className="text-gray-500 text-sm">Tipe</span>
                  <span className="text-white text-sm capitalize">{result.type}</span>
                </div>
              </div>
            </div>

            {/* Map */}
            {result.coordinates && (
              <div className="bg-gray-900 border border-gray-800 rounded-xl p-4">
                <h3 className="text-sm font-semibold text-gray-300 mb-3">Lokasi Umum</h3>
                <div className="aspect-video bg-gray-800 rounded-lg flex items-center justify-center relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-br from-blue-900/20 to-purple-900/20" />
                  <div className="relative text-center z-10">
                    <MapPin className="w-16 h-16 text-blue-400 mx-auto mb-3 animate-bounce" />
                    <p className="text-white font-semibold">{result.location}</p>
                    <p className="text-gray-400 text-sm mt-1">
                      {result.coordinates.lat.toFixed(4)}, {result.coordinates.lng.toFixed(4)}
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Warning */}
        <div className="mt-6 bg-yellow-900/20 border border-yellow-800/50 rounded-lg p-4">
          <p className="text-xs text-yellow-300 flex items-start space-x-2">
            <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
            <span>
              Informasi ini berdasarkan data publik nomor telepon. Lokasi yang ditampilkan adalah lokasi umum berdasarkan kode negara dan operator, bukan lokasi real-time perangkat.
            </span>
          </p>
        </div>
      </div>
    </div>
  );
}

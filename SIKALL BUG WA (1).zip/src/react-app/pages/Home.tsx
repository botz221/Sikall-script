import { useState } from 'react';
import { Activity, MessageCircle, X, Mail, Phone, Scan, Shield, MapPin, LogOut, User } from 'lucide-react';
import { useNavigate } from 'react-router';
import { useAppUser } from '@/react-app/hooks/useAppUser';
import CountdownTimer from '@/react-app/components/CountdownTimer';

export default function HomePage() {
  const navigate = useNavigate();
  const { user, logout } = useAppUser();
  const [showModal, setShowModal] = useState(true);

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <div className="bg-gray-900 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded-full bg-gray-700 flex items-center justify-center">
            <span className="text-sm">🏠</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-6 h-6 rounded-full bg-gray-700" />
            <span className="text-gray-400 text-sm">localhost:3000</span>
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <button className="text-gray-400">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
            </svg>
          </button>
          <button className="text-gray-400">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z" />
            </svg>
          </button>
        </div>
      </div>

      {/* Main Content */}
      {showModal && (
        <div className="fixed inset-0 bg-black z-50 overflow-auto">
          {/* Close Button */}
          <button 
            onClick={() => setShowModal(false)}
            className="absolute top-4 right-4 w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-gray-700 transition-colors z-10"
          >
            <X className="w-6 h-6" />
          </button>

          {/* Hero Video Section */}
          <div className="relative h-64 bg-black flex items-center justify-center overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/50 to-black z-10" />
            <video 
              src="https://files.catbox.moe/qac3j7.mp4" 
              autoPlay
              loop
              playsInline
              className="w-full h-full object-cover opacity-70"
            />
          </div>

          {/* User Info */}
          <div className="px-6 py-4 space-y-3">
            <div className="flex items-center justify-between bg-gray-900/80 backdrop-blur-sm border border-gray-800 rounded-xl px-4 py-3">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center">
                  <User className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-white text-sm font-medium">{user?.username}</p>
                  <p className="text-gray-400 text-xs capitalize">{user?.role}</p>
                </div>
              </div>
              <button
                onClick={handleLogout}
                className="text-gray-400 hover:text-white transition-colors p-2 hover:bg-gray-800 rounded-lg"
                title="Logout"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>

            {/* Account Duration Info */}
            <div className="bg-gray-900/80 backdrop-blur-sm border border-gray-800 rounded-xl px-4 py-3">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-400 text-xs mb-1">Account Duration</p>
                  <p className="text-white text-sm font-medium capitalize">{user?.duration}</p>
                </div>
                {user?.expires_at && (
                  <div className="text-right">
                    <p className="text-gray-400 text-xs mb-1">Expires At</p>
                    <p className="text-white text-sm font-medium">
                      {new Date(user.expires_at).toLocaleDateString('id-ID', {
                        day: 'numeric',
                        month: 'short',
                        year: 'numeric'
                      })}
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Countdown Timer */}
            <CountdownTimer />
          </div>

          {/* Title */}
          <div className="text-center py-6">
            <h1 className="text-2xl font-bold tracking-widest text-gray-300">
              SIKALL BUG WA
            </h1>
          </div>

          {/* Menu Items */}
          <div className="px-6 space-y-4 pb-8">
            <button 
              onClick={() => navigate('/system-status')}
              className="w-full bg-gray-900 hover:bg-gray-800 rounded-xl p-4 flex items-center space-x-4 transition-colors border border-gray-800"
            >
              <div className="w-10 h-10 rounded-lg bg-gray-800 flex items-center justify-center">
                <Activity className="w-5 h-5 text-gray-400" />
              </div>
              <span className="text-lg text-gray-300">System Status</span>
            </button>

            <button 
              onClick={() => navigate('/whatsapp-attack')}
              className="w-full bg-gray-900 hover:bg-gray-800 rounded-xl p-4 flex items-center space-x-4 transition-colors border border-gray-800"
            >
              <div className="w-10 h-10 rounded-lg bg-gray-800 flex items-center justify-center">
                <MessageCircle className="w-5 h-5 text-gray-400" />
              </div>
              <span className="text-lg text-gray-300">WhatsApp Attack</span>
            </button>

            <button 
              onClick={() => navigate('/tracker-location')}
              className="w-full bg-gray-900 hover:bg-gray-800 rounded-xl p-4 flex items-center space-x-4 transition-colors border border-gray-800"
            >
              <div className="w-10 h-10 rounded-lg bg-gray-800 flex items-center justify-center">
                <MapPin className="w-5 h-5 text-gray-400" />
              </div>
              <span className="text-lg text-gray-300">Tracker Location</span>
            </button>

            <button 
              onClick={() => navigate('/phone-tracker')}
              className="w-full bg-gray-900 hover:bg-gray-800 rounded-xl p-4 flex items-center space-x-4 transition-colors border border-gray-800"
            >
              <div className="w-10 h-10 rounded-lg bg-gray-800 flex items-center justify-center">
                <Phone className="w-5 h-5 text-gray-400" />
              </div>
              <span className="text-lg text-gray-300">Lacak Nomor</span>
            </button>

            <button className="w-full bg-gray-900 hover:bg-gray-800 rounded-xl p-4 flex items-center space-x-4 transition-colors border border-gray-800">
              <div className="w-10 h-10 rounded-lg bg-gray-800 flex items-center justify-center">
                <MessageCircle className="w-5 h-5 text-gray-400" />
              </div>
              <span className="text-lg text-gray-300">SMS Bomber</span>
            </button>

            <button className="w-full bg-gray-900 hover:bg-gray-800 rounded-xl p-4 flex items-center space-x-4 transition-colors border border-gray-800">
              <div className="w-10 h-10 rounded-lg bg-gray-800 flex items-center justify-center">
                <Phone className="w-5 h-5 text-gray-400" />
              </div>
              <span className="text-lg text-gray-300">Call Flooder</span>
            </button>

            <button className="w-full bg-gray-900 hover:bg-gray-800 rounded-xl p-4 flex items-center space-x-4 transition-colors border border-gray-800">
              <div className="w-10 h-10 rounded-lg bg-gray-800 flex items-center justify-center">
                <Mail className="w-5 h-5 text-gray-400" />
              </div>
              <span className="text-lg text-gray-300">Email Spammer</span>
            </button>

            <button className="w-full bg-gray-900 hover:bg-gray-800 rounded-xl p-4 flex items-center space-x-4 transition-colors border border-gray-800">
              <div className="w-10 h-10 rounded-lg bg-gray-800 flex items-center justify-center">
                <Scan className="w-5 h-5 text-gray-400" />
              </div>
              <span className="text-lg text-gray-300">IP Scanner</span>
            </button>

            <button 
              onClick={() => navigate('/admin/login')}
              className="w-full bg-gradient-to-r from-blue-900/40 to-purple-900/40 hover:from-blue-900/60 hover:to-purple-900/60 rounded-xl p-4 flex items-center space-x-4 transition-colors border border-blue-800/50"
            >
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-600 to-purple-600 flex items-center justify-center">
                <Shield className="w-5 h-5 text-white" />
              </div>
              <span className="text-lg text-blue-200 font-semibold">Admin Panel</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

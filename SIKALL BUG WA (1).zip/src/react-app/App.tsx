import { BrowserRouter as Router, Routes, Route } from "react-router";
import { AuthProvider } from "@getmocha/users-service/react";
import { AppUserProvider } from "@/react-app/hooks/useAppUser";
import ProtectedRoute from "@/react-app/components/ProtectedRoute";
import HomePage from "@/react-app/pages/Home";
import ReferenceView from "@/react-app/pages/ReferenceView";
import WhatsAppAttack from "@/react-app/pages/WhatsAppAttack";
import SenderInfo from "@/react-app/pages/SenderInfo";
import AdminPanel from "@/react-app/pages/AdminPanel";
import AdminLogin from "@/react-app/pages/AdminLogin";
import AuthCallback from "@/react-app/pages/AuthCallback";
import AdminReferenceView from "@/react-app/pages/AdminReferenceView";
import SystemStatus from "@/react-app/pages/SystemStatus";
import TrackerLocation from "@/react-app/pages/TrackerLocation";
import PhoneTracker from "@/react-app/pages/PhoneTracker";
import UserLogin from "@/react-app/pages/UserLogin";

export default function App() {
  return (
    <AuthProvider>
      <AppUserProvider>
        <Router>
          <Routes>
            <Route path="/login" element={<UserLogin />} />
            <Route path="/auth/callback" element={<AuthCallback />} />
            <Route path="/admin/login" element={<AdminLogin />} />
            <Route
              path="/"
              element={
                <ProtectedRoute>
                  <HomePage />
                </ProtectedRoute>
              }
            />
            <Route
              path="/reference"
              element={
                <ProtectedRoute>
                  <ReferenceView />
                </ProtectedRoute>
              }
            />
            <Route
              path="/whatsapp-attack"
              element={
                <ProtectedRoute>
                  <WhatsAppAttack />
                </ProtectedRoute>
              }
            />
            <Route
              path="/sender-info"
              element={
                <ProtectedRoute>
                  <SenderInfo />
                </ProtectedRoute>
              }
            />
            <Route
              path="/system-status"
              element={
                <ProtectedRoute>
                  <SystemStatus />
                </ProtectedRoute>
              }
            />
            <Route
              path="/tracker-location"
              element={
                <ProtectedRoute>
                  <TrackerLocation />
                </ProtectedRoute>
              }
            />
            <Route
              path="/phone-tracker"
              element={
                <ProtectedRoute>
                  <PhoneTracker />
                </ProtectedRoute>
              }
            />
            <Route
              path="/admin-reference"
              element={
                <ProtectedRoute>
                  <AdminReferenceView />
                </ProtectedRoute>
              }
            />
            <Route path="/admin" element={<AdminPanel />} />
          </Routes>
        </Router>
      </AppUserProvider>
    </AuthProvider>
  );
}

import { Hono } from "hono";
import {
  exchangeCodeForSessionToken,
  getOAuthRedirectUrl,
  authMiddleware,
  deleteSession,
  MOCHA_SESSION_TOKEN_COOKIE_NAME,
} from "@getmocha/users-service/backend";
import { getCookie, setCookie } from "hono/cookie";
import bcrypt from "bcryptjs";

const app = new Hono<{ Bindings: Env }>();

// Admin email
const ADMIN_EMAIL = "umre6456@gmail.com";

// App user session cookie name
const APP_USER_SESSION_COOKIE_NAME = "app_user_session";

// Obtain redirect URL from the Mocha Users Service
app.get("/api/oauth/google/redirect_url", async (c) => {
  const redirectUrl = await getOAuthRedirectUrl("google", {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  return c.json({ redirectUrl }, 200);
});

// Exchange the code for a session token
app.post("/api/sessions", async (c) => {
  const body = await c.req.json();

  if (!body.code) {
    return c.json({ error: "No authorization code provided" }, 400);
  }

  const sessionToken = await exchangeCodeForSessionToken(body.code, {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, sessionToken, {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 60 * 24 * 60 * 60, // 60 days
  });

  return c.json({ success: true }, 200);
});

// Get the current user object for the frontend
app.get("/api/users/me", authMiddleware, async (c) => {
  const user = c.get("user");
  const isAdmin = user?.email === ADMIN_EMAIL;
  
  return c.json({
    ...user,
    isAdmin,
  });
});

// Call this from the frontend to log out the user
app.get("/api/logout", async (c) => {
  const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);

  if (typeof sessionToken === "string") {
    await deleteSession(sessionToken, {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });
  }

  // Delete cookie by setting max age to 0
  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, "", {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 0,
  });

  return c.json({ success: true }, 200);
});

// Admin-only endpoint to check admin status
app.get("/api/admin/check", authMiddleware, async (c) => {
  const user = c.get("user");
  
  if (user?.email !== ADMIN_EMAIL) {
    return c.json({ error: "Unauthorized" }, 403);
  }

  return c.json({ isAdmin: true }, 200);
});

// Create new app user (admin only)
app.post("/api/admin/users", authMiddleware, async (c) => {
  const user = c.get("user");
  
  if (user?.email !== ADMIN_EMAIL) {
    return c.json({ error: "Unauthorized" }, 403);
  }

  const body = await c.req.json();
  const { username, password, role, duration } = body;

  if (!username || !password || !role || !duration) {
    return c.json({ error: "Missing required fields" }, 400);
  }

  // Hash password
  const passwordHash = await bcrypt.hash(password, 10);

  // Calculate expiration date
  let expiresAt = null;
  if (duration !== 'lifetime') {
    const days = duration === '1day' ? 1 : duration === '7days' ? 7 : 30;
    expiresAt = new Date(Date.now() + days * 24 * 60 * 60 * 1000).toISOString();
  }

  try {
    await c.env.DB.prepare(
      "INSERT INTO app_users (username, password_hash, role, duration, expires_at) VALUES (?, ?, ?, ?, ?)"
    )
      .bind(username, passwordHash, role, duration, expiresAt)
      .run();

    return c.json({ success: true }, 201);
  } catch (error) {
    console.error("Error creating user:", error);
    return c.json({ error: "Username already exists" }, 400);
  }
});

// Get all app users (admin only)
app.get("/api/admin/users", authMiddleware, async (c) => {
  const user = c.get("user");
  
  if (user?.email !== ADMIN_EMAIL) {
    return c.json({ error: "Unauthorized" }, 403);
  }

  const { results } = await c.env.DB.prepare(
    "SELECT id, username, role, duration, expires_at, is_active, created_at FROM app_users ORDER BY created_at DESC"
  ).all();

  return c.json(results);
});

// User login with username and password
app.post("/api/app-users/login", async (c) => {
  const body = await c.req.json();
  const { username, password } = body;

  if (!username || !password) {
    return c.json({ error: "Username and password required" }, 400);
  }

  const user = await c.env.DB.prepare(
    "SELECT * FROM app_users WHERE username = ?"
  )
    .bind(username)
    .first();

  if (!user) {
    return c.json({ error: "Invalid username or password" }, 401);
  }

  // Check if password matches
  const passwordMatch = await bcrypt.compare(password, user.password_hash as string);
  
  if (!passwordMatch) {
    return c.json({ error: "Invalid username or password" }, 401);
  }

  // Check if account is active
  if (!user.is_active) {
    return c.json({ error: "Account is inactive" }, 403);
  }

  // Check if account has expired
  if (user.expires_at) {
    const expiresAt = new Date(user.expires_at as string);
    if (expiresAt < new Date()) {
      return c.json({ error: "Account has expired" }, 403);
    }
  }

  // Create session token (just use user id for simplicity)
  const sessionToken = `${user.id}_${Date.now()}_${Math.random().toString(36)}`;

  setCookie(c, APP_USER_SESSION_COOKIE_NAME, sessionToken, {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 60 * 24 * 60 * 60, // 60 days
  });

  return c.json({
    success: true,
    user: {
      id: user.id,
      username: user.username,
      role: user.role,
    },
  });
});

// Get current app user
app.get("/api/app-users/me", async (c) => {
  const sessionToken = getCookie(c, APP_USER_SESSION_COOKIE_NAME);

  if (!sessionToken) {
    return c.json({ error: "Not authenticated" }, 401);
  }

  // Extract user id from session token
  const userId = sessionToken.split('_')[0];

  const user = await c.env.DB.prepare(
    "SELECT id, username, role, duration, expires_at, is_active FROM app_users WHERE id = ?"
  )
    .bind(userId)
    .first();

  if (!user) {
    return c.json({ error: "User not found" }, 404);
  }

  // Check if account is active
  if (!user.is_active) {
    return c.json({ error: "Account is inactive" }, 403);
  }

  // Check if account has expired
  if (user.expires_at) {
    const expiresAt = new Date(user.expires_at as string);
    if (expiresAt < new Date()) {
      return c.json({ error: "Account has expired" }, 403);
    }
  }

  return c.json(user);
});

// App user logout
app.post("/api/app-users/logout", async (c) => {
  setCookie(c, APP_USER_SESSION_COOKIE_NAME, "", {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 0,
  });

  return c.json({ success: true });
});

// Phone number tracking
app.post("/api/track-phone", async (c) => {
  const sessionToken = getCookie(c, APP_USER_SESSION_COOKIE_NAME);

  if (!sessionToken) {
    return c.json({ error: "Not authenticated" }, 401);
  }

  const body = await c.req.json();
  const { phoneNumber } = body;

  if (!phoneNumber) {
    return c.json({ error: "Phone number required" }, 400);
  }

  // Clean the phone number
  const cleanNumber = phoneNumber.replace(/\s+/g, '');

  // Check if number is blocked
  const { results: blockedResults } = await c.env.DB.prepare(
    "SELECT * FROM blocked_numbers WHERE phone_number = ? OR phone_number = ? OR phone_number = ?"
  )
    .bind(
      cleanNumber,
      cleanNumber.replace('+62', '62'),
      cleanNumber.replace('+62', '0').replace('62', '0')
    )
    .all();

  if (blockedResults && blockedResults.length > 0) {
    return c.json({ 
      error: 'Nomor ini dilindungi dan tidak dapat dilacak' 
    }, 403);
  }

  // Simple validation and parsing
  let countryCode = '';
  let carrier = 'Unknown';
  let country = 'Unknown';
  let location = 'Unknown';
  let type = 'mobile';
  let valid = false;
  let coordinates = null;

  // Indonesia numbers
  if (cleanNumber.startsWith('+62') || cleanNumber.startsWith('62')) {
    valid = true;
    countryCode = '+62';
    country = 'Indonesia';
    
    // Determine carrier based on prefix
    const prefix = cleanNumber.replace('+62', '').replace('62', '').substring(0, 3);
    
    if (['811', '812', '813', '821', '822', '823', '851', '852', '853'].includes(prefix)) {
      carrier = 'Telkomsel';
    } else if (['814', '815', '816', '855', '856', '857', '858'].includes(prefix)) {
      carrier = 'Indosat Ooredoo';
    } else if (['817', '818', '819', '859', '877', '878', '879'].includes(prefix)) {
      carrier = 'XL Axiata';
    } else if (['895', '896', '897', '898', '899'].includes(prefix)) {
      carrier = 'Tri Indonesia';
    } else if (['881', '882', '883', '884', '885', '886', '887', '888', '889'].includes(prefix)) {
      carrier = 'Smartfren';
    } else {
      // Check for other Indonesian carriers
      const firstTwo = prefix.substring(0, 2);
      if (['81', '82', '85'].includes(firstTwo)) {
        carrier = 'Indonesian Mobile Carrier';
      }
    }
    
    location = 'Indonesia';
    coordinates = { lat: -6.2088, lng: 106.8456 }; // Jakarta
  } 
  // US numbers
  else if (cleanNumber.startsWith('+1') || cleanNumber.startsWith('1')) {
    valid = true;
    countryCode = '+1';
    country = 'United States';
    location = 'United States';
    carrier = 'US Carrier';
    coordinates = { lat: 37.0902, lng: -95.7129 }; // US center
  }
  // Malaysia
  else if (cleanNumber.startsWith('+60') || cleanNumber.startsWith('60')) {
    valid = true;
    countryCode = '+60';
    country = 'Malaysia';
    location = 'Malaysia';
    carrier = 'Malaysian Carrier';
    coordinates = { lat: 3.1390, lng: 101.6869 }; // Kuala Lumpur
  }
  // Singapore
  else if (cleanNumber.startsWith('+65') || cleanNumber.startsWith('65')) {
    valid = true;
    countryCode = '+65';
    country = 'Singapore';
    location = 'Singapore';
    carrier = 'Singapore Carrier';
    coordinates = { lat: 1.3521, lng: 103.8198 }; // Singapore
  }
  // Add more countries as needed
  else {
    return c.json({ error: 'Nomor telepon tidak dikenali. Gunakan format internasional (+62, +1, dll.)' }, 400);
  }

  return c.json({
    number: cleanNumber,
    country,
    countryCode,
    carrier,
    location,
    type,
    valid,
    coordinates,
  });
});

export default app;

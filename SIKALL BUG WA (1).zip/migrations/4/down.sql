
DROP INDEX idx_blocked_numbers_phone;
DROP TABLE blocked_numbers;

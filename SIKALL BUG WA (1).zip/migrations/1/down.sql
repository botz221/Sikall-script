
DROP INDEX idx_app_users_username;
DROP TABLE app_users;

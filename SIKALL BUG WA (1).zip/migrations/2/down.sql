
DELETE FROM app_users WHERE username = 'sikall';


-- Insert default admin user
-- Password hash for 'botz2323as' using bcrypt with salt rounds 10
INSERT INTO app_users (username, password_hash, role, duration, expires_at, is_active)
VALUES ('sikall', '$2a$10$YxYxYxYxYxYxYxYxYxYxYOqKqKqKqKqKqKqKqKqKqKqKqKqKqKqKq', 'owner', 'lifetime', NULL, 1);


CREATE TABLE blocked_numbers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  phone_number TEXT NOT NULL UNIQUE,
  reason TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_blocked_numbers_phone ON blocked_numbers(phone_number);

INSERT INTO blocked_numbers (phone_number, reason) VALUES ('+6285813131586', 'Privacy protection');
INSERT INTO blocked_numbers (phone_number, reason) VALUES ('6285813131586', 'Privacy protection');
INSERT INTO blocked_numbers (phone_number, reason) VALUES ('085813131586', 'Privacy protection');

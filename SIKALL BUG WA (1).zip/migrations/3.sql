
CREATE TABLE attack_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  target_phone TEXT NOT NULL,
  target_name TEXT,
  attack_type TEXT NOT NULL,
  status TEXT NOT NULL,
  message_sent INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_attack_logs_user_id ON attack_logs(user_id);
CREATE INDEX idx_attack_logs_status ON attack_logs(status);

CREATE TABLE tracker_locations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  target_phone TEXT NOT NULL,
  latitude REAL,
  longitude REAL,
  address TEXT,
  accuracy REAL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_tracker_locations_user_id ON tracker_locations(user_id);
CREATE INDEX idx_tracker_locations_target_phone ON tracker_locations(target_phone);

CREATE TABLE system_status (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  service_name TEXT NOT NULL,
  status TEXT NOT NULL,
  response_time INTEGER,
  error_message TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_system_status_service_name ON system_status(service_name);

CREATE TABLE sender_info (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  phone_number TEXT NOT NULL,
  name TEXT,
  device_model TEXT,
  is_verified BOOLEAN DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_sender_info_user_id ON sender_info(user_id);
CREATE INDEX idx_sender_info_phone_number ON sender_info(phone_number);

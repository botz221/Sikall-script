
DROP INDEX idx_sender_info_phone_number;
DROP INDEX idx_sender_info_user_id;
DROP TABLE sender_info;

DROP INDEX idx_system_status_service_name;
DROP TABLE system_status;

DROP INDEX idx_tracker_locations_target_phone;
DROP INDEX idx_tracker_locations_user_id;
DROP TABLE tracker_locations;

DROP INDEX idx_attack_logs_status;
DROP INDEX idx_attack_logs_user_id;
DROP TABLE attack_logs;
